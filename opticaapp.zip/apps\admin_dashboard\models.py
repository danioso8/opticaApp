from django.db import models

# Los modelos se usan desde otras apps (User, UserSubscription, Organization)
