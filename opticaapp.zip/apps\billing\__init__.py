"""
Módulo de Facturación Electrónica y Pagos
Maneja facturas, pagos parciales e integración con DIAN
"""
default_app_config = 'apps.billing.apps.BillingConfig'
