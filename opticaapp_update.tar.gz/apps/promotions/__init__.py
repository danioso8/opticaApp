"""
Módulo de Promociones y Campañas de Marketing
"""
default_app_config = 'apps.promotions.apps.PromotionsConfig'
